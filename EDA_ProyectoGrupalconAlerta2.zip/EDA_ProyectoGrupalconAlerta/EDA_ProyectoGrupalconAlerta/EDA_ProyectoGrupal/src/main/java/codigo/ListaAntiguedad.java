package codigo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Mauricio Chulau
 */
public class ListaAntiguedad {
    NodoLista frente;
    NodoLista primero;
    int cuenta; //cuenta los elem ingresados
    //constructor
    public ListaAntiguedad(){
        
    }

    public int getCuenta() {
        return cuenta;
    }

    public NodoLista getFrente() {
        return frente;
    }

    public NodoLista getPrimero() {
        return primero;
    }
    
    static int id = 1;
    public void agregarFrente(int prioridad, int dni, String nombre, String email, String asunto, String docref, String fechainic){
        NodoLista temp=new NodoLista(id, prioridad, dni, nombre, email, asunto, docref, fechainic);
        if (frente==null){
            
            primero=temp; 
        }
        else{
            
            frente.sig=temp;  
        }
        
        frente=temp;
        cuenta++;
        
        id++;
        cuenta++;
    }
    
     public void borrar(int id){
        NodoLista prev=primero;
        NodoLista curr=primero.sig;
        if (primero.id==id){
            primero=primero.sig;
            cuenta--;
        }
        else{
            while (curr!=null){
                if (curr.id==id){
                    break;
                }
                else{
                    prev=prev.sig;
                    curr=curr.sig;
                }
            }
            if (curr==null) System.out.println("no encontrado");
            else{
                if (curr.sig==null) frente=prev;
                prev.sig=curr.sig;
                curr.sig=null;
                cuenta--;
            }
        }
    }
    
     
    public void imprimir(){
        NodoLista actual=primero;
        while(actual!=null){
            System.out.println(actual.id + " | "+ actual.prioridad + " | "+ actual.dni + " | " + actual.nombre + " | " + actual.email + " | "+ actual.asunto + " | " + actual.docref + " | " + actual.fechainic);
            actual=actual.sig;
        }
        
        if(primero == null){
            System.out.println("Lista vacia. Ingrese expedientes");
        }
        System.out.print("\n");
    }
    
    public boolean buscarEstado(int id){
        boolean encontrado = false;
        NodoLista actual = primero;
        while(actual != null){
            if (actual.id == id){
                encontrado = true;
            }
            actual = actual.sig;
        }
        return encontrado;
    }
    
}
