/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eda_proyecto;

/**
 *
 * @author Mauricio Chulau
 */
public class PilaAtendidos {

    NodoExpediente ultimo;
    NodoExpediente frente;
    int cuenta;
    public void apilar(NodoExpediente curr){
        NodoExpediente temp=curr;
        temp.sig=ultimo;
        ultimo=temp;
        if (frente==null){
            frente=temp;
        }
        cuenta++;
    }
    public void imprimir(){
        NodoExpediente actual=ultimo;
        while(actual!=null){
            System.out.print(actual.id+"-->");
            actual=actual.sig;
        }
        System.out.print("null");
        System.out.println();
    }
    //Puse desapilar por si acaso, aunque no creo que se use
    public int desapilar(){
        int n;
        if (estaVacio()){
            System.out.println("pila vacia");
            return -1;
        }
        else{
            n=ultimo.id;
            ultimo=ultimo.sig;
            cuenta--;
        }
        return n;
    }
    public boolean estaVacio(){
        if(ultimo==null) return true;
        else return false;
    }
    
}
