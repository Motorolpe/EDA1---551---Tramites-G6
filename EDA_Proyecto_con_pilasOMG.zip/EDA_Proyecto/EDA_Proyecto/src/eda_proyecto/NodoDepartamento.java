/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eda_proyecto;

/**
 *
 * @author jjoaq
 */
public class NodoDepartamento {
    int id;
    String departamento;
    public NodoDepartamento(){
        
    }
}
