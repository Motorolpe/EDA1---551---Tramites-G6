/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eda_proyecto;

/**
 *
 * @author Mauricio Chulau
 */
public class ColaPendientes {
    
    NodoExpediente ultimo;
    NodoExpediente frente;
    int cuenta;

    public ColaPendientes() {
    }
    
    public boolean estaVacia(){
        if (frente == null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    static int id = 1; //id autoincremental
    public void encolar(int prioridad, int dni, String nombre, String email, String asunto, String docref){  //Activado con un botón "AÑADIR EXPEDIENTE", usando datos de casillas, seguido de un print
        NodoExpediente temp = new NodoExpediente(id, prioridad, dni, nombre, email, asunto, docref);
        if(estaVacia())
        {
            frente = ultimo = temp;
        }
        else
        {
            temp.sig = ultimo;
            ultimo.prev = temp;
            ultimo = temp;
        }
        id++;
        cuenta++;
    }
    
    public NodoExpediente decolar(){ //Se usará en conjunto al botón "TERMINAR TRÁMITE"
        NodoExpediente blank = new NodoExpediente(-1); //Si está vacía, retorna un Nodo con id -1
        if (estaVacia())
        {
            return blank;
        }
        else if (this.cuenta == 1) 
        {
            NodoExpediente temp = new NodoExpediente(this.ultimo.id, this.ultimo.prioridad, this.ultimo.dni, this.ultimo.nombre, this.ultimo.email, this.ultimo.asunto, this.ultimo.docref);
            this.frente = null;
            this.ultimo = null;
            cuenta--;
            return temp;
        }
        else
        {
            this.frente = frente.prev;
            NodoExpediente temp = new NodoExpediente(this.frente.sig.id, this.ultimo.prioridad, this.frente.sig.dni, this.frente.sig.nombre, this.frente.sig.email, this.frente.sig.asunto, this.frente.sig.docref);
            this.frente.sig = null;
            cuenta--;
            return temp; //retorna el expediente del frente
        }
    }
    
    public void insertarFrente(int id, int prioridad, int dni, String nombre, String email, String asunto, String docref){
        NodoExpediente nuevo = new NodoExpediente(id, prioridad, dni, nombre, email, asunto, docref);
        this.frente.sig = nuevo;
        nuevo.prev = this.frente;
        this.frente = nuevo;
        this.cuenta++;
    }
    
    public void quitarUltimo()
    {
        this.ultimo = this.ultimo.sig;
        this.ultimo.prev = null;
        cuenta--;
    }

    
    public void reordenar() //Se realizará automáticamente después de imprimir la cola desordenada con el botón "AÑADIR EXPEDIENTE", seguido de un print de la cola ordenada
    {
        
        if(cuenta >= 1)
        {
            
            //Nodo con los mismos datos que el ultimo, será insertado entre actual y actual.sig
            NodoExpediente temp = new NodoExpediente(this.ultimo.id, this.ultimo.prioridad, this.ultimo.dni, this.ultimo.nombre, this.ultimo.email, this.ultimo.asunto, this.ultimo.docref);

            //avanza hasta encontrar un nodo con mayor prioridad
            NodoExpediente actual = this.ultimo;
            int movimientos = 0;

            while(actual.sig != null && temp.prioridad < actual.sig.prioridad)
            {
               actual = actual.sig;
               movimientos++;
            }


            //Inserción
            if (movimientos == 0) //si no recorre, no hay que ordenar
            {
                System.out.println("Sin movimiento");
            }
            else if (actual == this.frente && movimientos > 0) //Si ha hecho almenos un recorrido y llega hasta el frente, entonces tiene la mayor prioridad
            {
                //Inserta Nodo con los mismos datos que el ultimo al frente
                //this.insertarFrente(this.ultimo.id, this.ultimo.prioridad, this.ultimo.id, this.ultimo.nombre, this.ultimo.email, this.ultimo.asunto, this.ultimo.docref);
                this.frente.sig = temp;
                temp.prev = this.frente;
                frente = temp;
                
                cuenta++;
                //borra el nodo repetido que ya ha sido insertado en la pos adecuada
                quitarUltimo();
            }
            else if (movimientos > 0)
            {
                //Conexiones al nuevo
                temp.sig = actual.sig;
                temp.prev = actual;
                //Romper conexiones antiguas
                actual.sig.prev = temp;
                actual.sig = temp;
                
                cuenta++;
                //borra el nodo repetido que ya ha sido insertado en la pos adecuada
                quitarUltimo();

            }
            
            
        } //fin if  
        else
        {
            System.out.println("Cola vacia: No se puede ordenar");
        }
        
       
    } //fin reordenar
    
    
    public void imprimirID()
    {
        int cant = 1;
        NodoExpediente actual = ultimo;
        if (cuenta == 0)
        {
            System.out.println("cola vacia");
        }
        else if(cuenta == 1)
        {
            System.out.println(actual.id);
        }
        while (cant<=cuenta)
        {
            System.out.print(actual.id+" ");
            actual = actual.sig;
            cant++;
        }
    }
    
    public void imprimirPrioridad()
    {
        int cant = 1;
        NodoExpediente actual = ultimo;
        if (cuenta == 0)
        {
            System.out.println("cola vacia");
        }
        while (cant<=cuenta)
        {
            System.out.print(actual.prioridad+" ");
            actual = actual.sig;
            cant++;
        }
    }
}

