/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

/**
 *
 * @author Mauricio Chulau
 */
public class ListaDepartamentos {
    
    NodoDepartamento frente;
    NodoDepartamento primero;
    int cuenta;

    public NodoDepartamento getFrente() {
        return frente;
    }

    public NodoDepartamento getPrimero() {
        return primero;
    }

    public int getCuenta() {
        return cuenta;
    }
    
    public void agregarFrenteDep(NodoExpediente exp, String departamento) //Activado al apilar un tramite. Llama al nodo apilado + departamento + su fecha
    {
        NodoDepartamento temp = new NodoDepartamento(exp.id, departamento, exp.fechafin);
        if (frente==null)
        {
            primero=temp; 
        }
        else
        {
            frente.sig=temp;  
        }
        
        frente=temp;
        cuenta++;
    }
    
    
    public void editarDep(int id, String departamentoNuevo, String fechaNueva) //Activado cuando se quiera cambiar dependencia
    {
        NodoDepartamento temp = this.primero;
        
        while(temp != null)
        {
            if (temp.id == id) 
            {
                temp.departamento = departamentoNuevo;
                temp.fecha = fechaNueva;
                break;
            }
            else
            {
                temp = temp.sig;
                cuenta++;
            }
        }
    }
    
    public void imprimirDep() //Print general de todas las dependencias
    {
        NodoDepartamento actual = primero;
        while(actual!=null)
        {
            System.out.println(actual.id + " | "+ actual.departamento + " | "+ actual.fecha);
            actual=actual.sig;
        }
        
        if(primero == null)
        {
            System.out.println("Lista vacia. Ingrese dependencias");
        }
        System.out.print("\n");
    }
    
    public NodoDepartamento imprimirNodoporId(NodoDepartamento nuevo, int id) //Print de las dependencias por departamento especifico
    {
        NodoDepartamento actual = primero;
        while(actual!=null)
        {
            if (actual.id == id) 
            {
                nuevo = actual;
            }
            actual=actual.sig;
        }
        
        return nuevo;
    }
    
    
    
}
