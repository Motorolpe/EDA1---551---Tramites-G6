package codigo;

public class ListaCircularAlerta {
    NodoLista frente;
    NodoLista primero;
    
    public void ListaCircularAlerta(){
        
    }

    public NodoLista getFrente() {
        return frente;
    }

    public NodoLista getPrimero() {
        return primero;
    }
    
    
    public void agregarFrente(NodoLista nodo){
        //Crea un nuevo nodoLista para no confundir los .sig de cada nodo que recorra de la lista simple
        NodoLista nuevo = new NodoLista(nodo.id, nodo.prioridad, nodo.dni, nodo.nombre, nodo.email, nodo.asunto, nodo.docref, nodo.fechainic);
        NodoLista actual = primero; //actual recorrera la lista circular
        NodoLista previo = null;
        boolean primeraVuelta = true; // si es que ya se dio la primera vuelta o no
        if (primero == null){ //en caso de que la lista este vacia solo ingresa
            primero = frente = nuevo;
            frente.sig = primero;
            return;
        }
        
        while (actual != primero || primeraVuelta){ //para que actual llegue a terminar el bucle
            primeraVuelta = false; //ya dio la primera vuelta
            
            if(nuevo.prioridad < actual.prioridad){ //posicion para el NodoLista encontrada
                break;
            }
            previo = actual;
            actual = actual.sig;
        }
        
        if (previo == null){//el nuevo NodoLista tiene la mejor prioridad
            nuevo.sig = primero;
            primero = nuevo;
            frente.sig = primero;
        }
        else{
            //esta entre la lista o al final
            previo.sig = nuevo;
            nuevo.sig = actual;
            
            if (actual == primero){ //en caso de que haya llegado hasta el final de toda la lista, es decir tiene la peor prioridad
                frente = nuevo;
            }
        }
    }
    
    public void imprimirCircular(){
        NodoLista actual = primero;
        boolean primeraV = true;
        while(actual != primero || primeraV == true){
            System.out.println(actual.id + " | "+ actual.prioridad + " | "+ actual.dni + " | " + actual.nombre + " | " + actual.email + " | "+ actual.asunto + " | " + actual.docref + " | " + actual.fechainic);
            actual = actual.sig;
            primeraV = false;
        }
    }

}
