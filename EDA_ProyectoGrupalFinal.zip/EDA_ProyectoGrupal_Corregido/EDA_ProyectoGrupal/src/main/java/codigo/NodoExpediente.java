package codigo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Mauricio Chulau
 */
public class NodoExpediente 
{
    NodoExpediente sig;
    NodoExpediente prev;
    
    int id, prioridad, dni, cdoc=0;
    String nombre, email, asunto, docref;
    String fechainic, fechafin;
    String[] docfinal=new String[5];

    //Al crear y encolar expediente (añade id autoincremental)
    public NodoExpediente(int id, int prioridad, int dni, String nombre, String email, String asunto, String docref) {
        this.id = id;
        this.prioridad = prioridad;
        this.dni = dni;
        this.nombre = nombre;
        this.email = email;
        this.asunto = asunto;
        this.docref = docref;
    }
    
    //Usos variados (cola vacía, ....)
    public NodoExpediente(int id) {
        this.id = id;
    }

    public NodoExpediente getSig() {
        return sig;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public NodoExpediente getPrev() {
        return prev;
    }

    public int getId() {
        return id;
    }

    public int getDni() {
        return dni;
    }

    public int getCdoc() {
        return cdoc;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getAsunto() {
        return asunto;
    }

    public String getDocref() {
        return docref;
    }

    public String getFechainic() {
        return fechainic;
    }

    public String getFechafin() {
        return fechafin;
    }

    public String[] getDocfinal() {
        return docfinal;
    }

    public void setFechafin(String fechafin) {
        this.fechafin = fechafin;
    }

    public void setFechainic(String fechainic) {
        this.fechainic = fechainic;
    }
    
     
    
    
    
    
    
}
