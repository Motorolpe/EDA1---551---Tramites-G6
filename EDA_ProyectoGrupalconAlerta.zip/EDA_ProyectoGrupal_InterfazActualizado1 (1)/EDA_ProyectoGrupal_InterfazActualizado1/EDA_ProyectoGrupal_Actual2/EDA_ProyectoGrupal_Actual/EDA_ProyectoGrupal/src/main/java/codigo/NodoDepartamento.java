package codigo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author jjoaq
 */
public class NodoDepartamento {
    
    NodoDepartamento sig;
    
    int id;
    String departamento;
    String fecha;

    public NodoDepartamento(int id, String departamento, String fecha) {
        this.id = id;
        this.departamento = departamento;
        this.fecha = fecha;
    }

    
    
    
}
