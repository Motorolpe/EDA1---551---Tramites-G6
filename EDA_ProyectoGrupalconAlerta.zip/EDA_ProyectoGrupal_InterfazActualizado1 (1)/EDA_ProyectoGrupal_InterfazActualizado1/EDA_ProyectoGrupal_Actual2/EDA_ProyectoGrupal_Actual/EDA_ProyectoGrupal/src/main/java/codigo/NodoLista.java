package codigo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author jjoaq
 */
public class NodoLista {
    NodoLista sig;
    
    int id, prioridad, dni;
    String nombre, email, asunto, docref;
    String fechainic;
    
    public NodoLista(int id, int prioridad, int dni, String nombre, String email, String asunto, String docref, String fechainic) {
        this.id = id;
        this.prioridad = prioridad;
        this.dni = dni;
        this.nombre = nombre;
        this.email = email;
        this.asunto = asunto;
        this.docref = docref;
        this.fechainic = fechainic;
    }

    public NodoLista getSig() {
        return sig;
    }

    public int getId() {
        return id;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public int getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getAsunto() {
        return asunto;
    }

    public String getDocref() {
        return docref;
    }

    public String getFechainic() {
        return fechainic;
    }
    
    
}
