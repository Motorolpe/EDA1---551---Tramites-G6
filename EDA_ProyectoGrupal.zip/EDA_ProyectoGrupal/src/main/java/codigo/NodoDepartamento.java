package codigo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author jjoaq
 */
public class NodoDepartamento {
    int id;
    String departamento;
    public NodoDepartamento(){
        
    }
}
