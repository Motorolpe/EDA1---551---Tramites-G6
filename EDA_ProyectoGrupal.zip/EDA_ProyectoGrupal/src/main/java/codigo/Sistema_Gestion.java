package codigo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Mauricio Chulau
 */
public class Sistema_Gestion {
    
    public static void main(String[] args) 
    {
        
        System.out.println("DEMOSTRACION TIEMPO");
        
        LocalDateTime fechaObj = LocalDateTime.now();
        //System.out.println("Before formatting: " + fechaObj);
        
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String fechainic = fechaObj.format(myFormatObj); //nodo.fechainic
        System.out.println("Fecha inicio: " + fechainic);
        
        System.out.println("");
        LocalDateTime fechaObj2 = LocalDateTime.now();
        //System.out.println("Before formatting: " + fechaObj2);
        
        DateTimeFormatter myFormatObj2 = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String fechafin = fechaObj2.format(myFormatObj2); //nodo.fechafin
        System.out.println("Fecha fin: " + fechafin);
        
        
        System.out.println("---------TEST COLA---------");
        System.out.println("");
        
        System.out.println("--TEST VACIO--"); //-------
        System.out.println(""); 
        ColaPendientes c = new ColaPendientes();
        System.out.println("cola vacia? "+c.estaVacia());
        
        System.out.println("");
        c.encolar(2, 73212545, "Mau", "Mau@gmail.com", "Cambiar carrera", "Matricula");
        c.encolar(3, 12345678, "Pepe", "Pepe@gmail.com", "Retirarse", "Doc 2");
        c.encolar(4, 23456789, "Chistopher", "Chistopher@gmail.com", "filosofear", "Doc 3");
        c.encolar(1, 99999999, "Edwin", "Edwin@gmail.com", "graduar", "Doc 4");
        System.out.println("cola vacia? "+c.estaVacia());
        c.imprimirID();
        System.out.println("");
        System.out.println("frente cola: " +c.frente.nombre); //Orden prioridad: 1 4 3 2
        System.out.println("N elem cola: " + c.cuenta);
        
        //Orden prioridad meta al ordenar: 4 3 2 1
        System.out.println("");
        System.out.println("--TEST REORDENAR--");
        System.out.println("Prioridades antes: ");
        c.imprimirPrioridad();
        System.out.println("");
        System.out.println("Prioridades despues: ");
        c.reordenar();
        c.imprimirPrioridad();
        System.out.println("");
        System.out.println("N elem cola: " + c.cuenta);
        
        
        System.out.println("");
        System.out.println("");
        /*
        System.out.println("--TEST DECOLAR--");
        c.imprimirID();
        System.out.println("");
        System.out.println("Se decola: "+ c.decolar().id);
        c.imprimirID();
        System.out.println("");
        System.out.println("frente cola: " +c.frente.nombre);
        System.out.println("N elem cola: " + c.cuenta);
        */
        
        System.out.println("Parte Joaquin Pilas");
        System.out.println("--TEST PILA ATENDIDOS--");
        PilaAtendidos p = new PilaAtendidos();
        System.out.println("Lista ID");
        c.imprimirID();
        p.apilar(c.decolar());
        //Se deberia apilar del primero que se atendio al ultimo;
        System.out.println("\nLista de atendidos por id");
        p.imprimir();
        System.out.println("Nueva lista ID");
        c.imprimirID();
        //JJ: Se debe usar el decolar con el apilar para que funcione
        
        System.out.println("");
        System.out.println("Parte Listas Adolfo");
        System.out.println("--TEST LISTA ANTIGUEDAD--");
        ListaAntiguedad la = new ListaAntiguedad();
        System.out.println("Lista sin datos");
        la.imprimir();
        la.agregarFrente(2, 73212545, "Mau", "Mau@gmail.com", "Cambiar carrera", "Matricula", fechainic);
        la.agregarFrente(3, 12345678, "Pepe", "Pepe@gmail.com", "Retirarse", "Doc 2", fechainic);
        la.agregarFrente(4, 23456789, "Chistopher", "Chistopher@gmail.com", "filosofear", "Doc 3", fechainic);
        la.agregarFrente(1, 99999999, "Edwin", "Edwin@gmail.com", "graduar", "Doc 4", fechainic);
        System.out.println("Lista llena");
        la.imprimir();
        System.out.println("Eliminar un expediente ya tramitado");
        la.borrar(p.ultimo.id);
        la.imprimir();
        
        c.imprimirID();
        
        
        
        
        
    }
    
    
}
