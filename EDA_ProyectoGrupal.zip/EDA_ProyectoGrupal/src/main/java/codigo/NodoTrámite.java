package codigo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Mauricio Chulau
 */
public class NodoTrámite {
    
    NodoTrámite sig;
    NodoTrámite prev;
    
    int id, prioridad, dni;
    String nombre, email, asunto, docref;
    String fechainic, fechafin;
    String[] docfinal;

    //Recibe los datos de un NodoExpediente para crearse
    public NodoTrámite(int id, int prioridad, int dni, String nombre, String email, String asunto, String docref) {
        this.id = id;
        this.prioridad = prioridad;
        this.dni = dni;
        this.nombre = nombre;
        this.email = email;
        this.asunto = asunto;
        this.docref = docref;
    }
    
    
}
